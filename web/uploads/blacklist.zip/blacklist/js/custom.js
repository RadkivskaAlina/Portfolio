$(document).ready(function(){
    $('#phone').mask("(999) 99 99 999");
})