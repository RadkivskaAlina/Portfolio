<?php

return [
    'Главная' => 'Main Page',
    'Про нас' => 'About us',
    'Проверить номер' => 'Check number',
    'Антирейтинг' => 'The worsts',
    'Проверить организацию' => 'Check company',
    'ФЛП Андриенко В. П.' => 'Andrienko V. P.',
    'Последний комментарий' => 'Last comment',
    'Жалобы' => 'Complaints',
    'Остались вопросы? Напишите нам' => 'Have questions? Write to us',
    'Наша команда' => 'Our team',
    'Проверить номер телефона или организацию' => 'Check phone number or company',
    'Добавить номер телефона или организацию в черный список' => 'Add phone number or company to black list',
    'Изменить тему' => 'Change Theme',
    'Добавить номер в черный список' => 'Add phone number to black list',
    'Добавить организацию в черный список' => 'Add company to black list',
];