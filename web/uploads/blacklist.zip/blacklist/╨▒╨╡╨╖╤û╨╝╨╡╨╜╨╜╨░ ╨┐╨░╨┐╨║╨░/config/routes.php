<?php
return [
    '' => 'site/index',
    'check/phone/([1-9])' => 'site/checkPhone/$1',


//    'about' => 'site/about',
//    'auth/signup' => 'auth/signup',

//    language route
    '([e,r,u][n,u,a])' => 'site/lang/$1',

    //routes for admin panel
//    'admin/page' => 'adminPage/index',
];
?>