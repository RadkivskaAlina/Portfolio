<?php
if (!defined('DB_SERVER')) define('DB_SERVER', 'localhost');
if (!defined('DB_NAME')) define('DB_NAME', 'black_label_20200704');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASSWORD')) define('DB_PASSWORD', 'root');
//define('DB_SERVER', 'localhost');
//define('DB_NAME', 'black_label_20200704');
//define('DB_USER', 'root');
//define('DB_PASSWORD', 'root');
?>