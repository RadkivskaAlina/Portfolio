<form action="" method="post">
    <input type="text" name="login" placeholder="Login" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="password" name="password_repeat" placeholder="Password repeat" required>
    <input type="submit" value="Signup">
</form>